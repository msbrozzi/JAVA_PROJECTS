package test;

import it.salestaxes.receipt.MainProcessor;

public class RunTest02 {

	public static void main(String[] args) {
		
		// Init
		String[] arguments;
		
		// Test INPUT 02
		arguments = new String[] {"./input/Input02.xml"};
		MainProcessor.main(arguments);
		
	}
	
}
