package test;

import it.salestaxes.receipt.MainProcessor;

public class RunTest03 {

	public static void main(String[] args) {
		
		// Init
		String[] arguments;
		
		// Test INPUT 03
		arguments = new String[] {"./input/Input03.xml"};
		MainProcessor.main(arguments);
		
	}
	
}
